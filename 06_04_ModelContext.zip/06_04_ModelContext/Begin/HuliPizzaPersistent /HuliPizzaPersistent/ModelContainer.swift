//
//  ModelContainer.swift
//  HuliPizzaPersistent
//
//  Created by Steven Lipton on 1/21/24.
//

import Foundation
import SwiftData

var modelContainer:ModelContainer{
    let schema = Schema([OrderTicket.self,NameModel.self,RatingModel.self,OrderItem.self])
    let modelConfiguration = ModelConfiguration( )
    let modelContainer = try! ModelContainer(for: schema, configurations: modelConfiguration)
    return modelContainer
}
